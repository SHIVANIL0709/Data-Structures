#include<iostream>
using namespace std;

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

struct node
{
	int data;
	struct node *next;
};

class list
{
	private:
		PNODE  *head;
	public:
		list();
		bool InsertFirst(PPNODE,int);
		bool InsertLast(PPNODE,int);
		bool InsertPos(PPNODE,int,int);
		bool DeleteFirst(PPNODE);
		bool DeleteLast(PPNODE);
		bool DeletePos(PPNODE,int);
		void display(PNODE);
		int count(PNODE);
};
