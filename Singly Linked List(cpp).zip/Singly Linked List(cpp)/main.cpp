#include"list.h"

int main()
{
	list obj;
	int num,choice,pos;
	PNODE head=NULL;
	bool ret;
	while(1)
	{
	cout<<"1- Insert at first"<<endl;
	cout<<"2- Insert at last"<<endl;
	cout<<"3- Insert at position"<<endl;
	cout<<"4- Delete from first"<<endl;
	cout<<"5- Delete from last"<<endl;
	cout<<"6- Delete at position"<<endl;
	cout<<"7- display"<<endl;
	cout<<"8- count"<<endl;
	cout<<"Enter your choice:"<<endl;
	cin>>choice;
	
	switch(choice)
	{
	case 1:
		cout<<"Enter the number:"<<endl;
       		cin>>num;
		ret=obj.InsertFirst(&head,num);
		//cout<<ret<<endl;
		break;

	case 2:
		cout<<"Enter the number:\n"<<endl;
                cin>>num;
                ret=obj.InsertLast(&head,num);
               // cout<<ret<<endl;
                break;
	
	case 3:
		cout<<"Enter the number:\n"<<endl;
                cin>>num;
		cout<<"Enter the position:\n"<<endl;
		cin>>pos;
                ret=obj.InsertPos(&head,num,pos);
                //cout<<ret<<endl;
                break;

	case 4:
		ret=obj.DeleteFirst(&head);
		//cout<<ret<<endl;
		break;
	
	case 5:
		ret=obj.DeleteLast(&head);
		break;

	case 6:
		cout<<"Enter position"<<endl;
		cin>>pos;
		obj.DeletePos(&head,pos);
		break;
	case 7:
		obj.display(head);
		break;
	case 8:
		cout<<obj.count(head);
		break;

	}
	}
}
