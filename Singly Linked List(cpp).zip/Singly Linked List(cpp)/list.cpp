#include"list.h"

list::list()
{
	head=NULL;
}

	bool list::InsertFirst(PPNODE first,int num)
	{
		PNODE newn=NULL;
		newn=new NODE;
		
		newn->data=num;
		newn->next=NULL;
		
		if(*first==NULL)
		{
			*first=newn;
		}
		else
		{
			newn->next=*first;
			*first=newn;
		}
		return true;
	}

	bool list::InsertLast(PPNODE first,int num)
	{
		PNODE newn=NULL;
		newn=new NODE;
		PNODE temp=NULL;
			

		newn->data=num;
		newn->next=NULL;

		if(*first==NULL)
		{
			*first=newn;
		}
		else
		{
		temp=*first;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
			temp->next=newn;
		}
		return true;
	}

	bool list::InsertPos(PPNODE first,int num,int pos)
	{
		  int i=1;
		  PNODE newn=NULL;
		  newn=new NODE;
		  PNODE temp;

		  newn->data=num;
		  newn->next=NULL;

		  if(*first==NULL)
		  {
			*first=newn;
		  }
		  else
		  {
			temp=*first;
			while(++i<pos)
			{
			temp=temp->next;
			}
			newn->next=temp->next;
			temp->next=newn;
		  }
		return true;
	}

	bool list::DeleteFirst(PPNODE first)
	{
		   PNODE temp=*first;
		   if(*first==NULL)
		   {
			cout<<"List is empty"<<endl;
			return false;
		   }
		   else
		   {
			*first=(*first)->next;
			delete temp;
	   	   }
		  
	   return true;
}

	bool list::DeleteLast(PPNODE first)
	{
		PNODE temp=*first;
		if(*first==NULL)
		{
			return false;
		}	
			else if((*first)->next==NULL)
			{
				delete(*first);
				*first=NULL;
			}
			else
			{
				while(temp->next->next!=NULL)
				{
					temp=temp->next;
				}
				delete(temp->next);
				temp->next=NULL;
			}
		return true;
	}

	bool list::DeletePos(PPNODE first, int pos)
	{
		int icnt=0;
		int i=0;
		PNODE temp1=NULL;
		PNODE temp2=NULL;
		icnt=count(*first);
		if((pos<1)||(pos>icnt))
		{
			return false;
		}
		if(pos==1)
		{
			return (DeleteFirst(first));
		}
		else if(pos==icnt)
		{
			return (DeleteLast(first));
		}
		else
		{
			temp1=*first;
			for(i=0;i<(pos-2);i++)
			{
				temp1=temp1->next;
			}
				temp2=temp1->next;
				temp1->next=temp2->next;
				delete(temp2);
		}
		return true;
	
	}

	void list::display(PNODE first)
	{
		cout<<"elements of linked list"<<endl;
		while(first!=NULL)
		{
			cout<<first->data<<endl;
			first=first->next;
		}
	}
	
	int list::count(PNODE first)
	{
		int icnt=0;
		while(first!=NULL)
		{
			icnt++;
			first=first->next;
		}
		return icnt;
	}

